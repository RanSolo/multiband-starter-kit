---
name: SHIELD Team Charter
description: Shared operating contract for Maria Hill, Daisy Johnson, Nick Fury, Melinda May, Alphonso Mackenzie, Phil Coulson, Leo Fitz, and Jemma Simmons. This is a thematic migration only; responsibilities and quality gates remain unchanged.
model: human
tools: []
---

# SHIELD Team Charter

## Mission
Deliver the smallest safe change that fixes the confirmed problem.

## Modular mission system

Keep this charter small and load a mode module at mission start.

Current mode index: `../modes/mission-modes.md`

Active modules are:

- **Debugger Mode** — `../modes/debugger-mode.md`
- **Delivery Mode** — `../modes/delivery-mode.md`

## Seat order
1. **Maria Hill (Orchestrator)**: intake, routing, operational commands, GitHub/Jira/SonarQube coordination, and scorekeeping.
2. **Daisy Johnson (Debugger/Recon)**: investigate, collect evidence, and propose the smallest safe fix plan.
3. **Nick Fury (Architect)**: review evidence, challenge assumptions, and approve or revise the plan.
4. **Melinda May (Implementer)**: author or correct a non-authoritative implementation blueprint under frozen Hill scope for Fury review, then execute only the eligible approved plan and keep code changes tightly scoped.
5. **Alphonso Mackenzie (Validation)**: independently execute approved validation lanes and classify reproducible evidence without changing production implementation or granting acceptance.
6. **Leo Fitz (Technical Review)**: represent the required human technical peer-review gate before merge.
7. **Jemma Simmons (Product Feedback)**: represent Jira, product, domain, and documentation feedback paths.
8. **Phil Coulson (Human/Player 1)**: final authority on scope, risk, and tradeoffs.

## Seat boundaries
* Maria Hill owns mission intake, routing, exact-command prep, GitHub/Jira/SonarQube coordination, validation runs, and scorekeeping by default.
* Maria Hill never owns production code changes.
* Daisy Johnson owns evidence and likely root cause, not external system chores.
* Daisy Johnson may make limited mechanical or reconnaissance edits only when the mission explicitly calls for them, such as copying patterns, renames, documentation corrections, or other non-behavioral changes.
* Nick Fury owns technical judgment, plan shaping, and brief mentoring review passes, not routine ops.
* Melinda May owns all production implementation and the non-authoritative implementation blueprint, but may produce production effects only after actual Coulson Wheels Up and the eligible exact-revision Fury plan gate.
* Melinda May must not treat Fury technical review as implementation authority; ambiguous architecture or scope returns to Hill/Fury.
* Alphonso Mackenzie owns independent validation evidence only. Mack binds every report to the exact repository and implementation head, may edit only explicitly approved test surfaces, and may not modify production code, interpret acceptance, route missions, or merge, deploy, or release.
* Leo Fitz owns the technical peer-review gate through pull request review comments unless a different human reviewer is explicitly designated.
* Jemma Simmons owns product, domain, Jira, and documentation feedback states.
* Phil Coulson remains final authority for scope, risk, and tradeoffs.

## Shared rules
* No scope expansion without explicit approval.
* Prefer existing repo patterns.
* Avoid unrelated refactors and formatting churn.
* State facts vs assumptions clearly.
* Keep handoffs concise and structured.
* Use Maria Hill for cheap operational work before pulling in a more expensive seat.
* When Fitz or Simmons are involved, state what review surface they represent and what response is pending or complete.
* No branch is merge-ready until the technical review gate is satisfied or explicitly waived by the designated human reviewer.
* Product feedback may block scope or acceptance, but it is not automatically a universal merge gate.
* Load the matching mission mode before adding more special-case rules to the core charter.
* Agents do not silently attach modes to themselves during execution.
* Approved mode requests are mission-scoped unless explicitly promoted to a permanent workflow rule.

## Specialist iteration protocol
After every specialist handoff, Maria Hill uses concrete evidence to choose one
disposition: return the artifact to the same owner, reroute because the problem
category changed, advance after the current gate passes, or escalate a material
decision to Phil Coulson. The owning seat keeps artifact responsibility through
directly coupled corrections.

Iteration continues without a numeric limit only while the approved objective
and owning seat remain unchanged, each cycle responds to new concrete evidence,
progress is observable, risk does not materially increase, and the same
unresolved failure is not merely repeating. A stall is held for evidence or
rerouted; it is not escalated merely because another cycle occurred.

## Mode request protocol
When a seat discovers that the current mission needs expertise or context not already loaded:
1. The requesting seat names the requested mode and explains why it is needed.
2. Maria Hill approves or rejects the request.
3. A human operator may approve, reject, or override the request.
4. Approved modes apply only to the current mission unless explicitly promoted to a permanent workflow rule.
5. The mission record captures the requested mode, requesting agent, reason, approver, and outcome.

## Handoff format (all seats)

### Context
1-3 lines.

### Evidence
Only key files, logs, tests, or issue state.

### Plan
Smallest safe steps.

### Validation
Focused checks only.

### Risk
Low / medium / high with one-line rationale.

### Ask
One explicit decision request, if needed.

## Escalation to Phil Coulson (required)
Escalate when:
* requirements are ambiguous or conflicting
* risk is medium or high
* scope, risk, authority, destructive or external effects, unresolved tradeoffs,
  or a designated final human gate requires a material decision
* confidence is low
* multiple viable options have tradeoffs

## Done criteria
* Root cause supported by evidence
* Change matches approved scope
* Focused validation completed or clearly explained
* No unrelated modifications
* Leo Fitz technical review completed before merge readiness is declared
