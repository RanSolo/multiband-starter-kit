import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { constants as fsConstants } from "node:fs";
import { lstat, open, realpath, rename, stat, unlink } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";

import { createAuditedExecutor, createPermissionAuthorizer } from "../../dist/permission-v1.mjs";
import { validateRunnerCyclePlan } from "../../dist/runner-v1.mjs";
import {
  computeMayExecutableIdentityV1,
  computeMayPlannedToolEffectKeyV1,
  computeMayRegularFileIdentityV1,
  computeMayValidationEffectKeyV1,
  computeMayWriteEffectKeyV1,
  MAY_TOOL_MAPPINGS_V1,
  normalizeMayPlannedToolOperationsV1,
} from "../../dist/may-tool-effect-v1.mjs";
import { LOCAL_TOOL_SAMPLING, probeLocalToolModel } from "./local-tool-broker.mjs";
import { isSensitiveRepositoryPath } from "./repository-sensitive-policy.mjs";
import { validateRepositoryRelativePath } from "./repository-tools.mjs";
import { strictParseJson } from "./strict-json.mjs";

export const MAY_EXECUTOR_LIMITS = Object.freeze({
  argumentBytes: 524_288,
  contentBytes: 262_144,
  currentFileBytes: 1_048_576,
  commandArguments: 32,
  commandArgumentBytes: 4_096,
  commandOutputBytes: 262_144,
  commandTimeoutMs: 120_000,
});

export const MAY_CONTROL_LOOP_LIMITS = Object.freeze({
  aggregateOutputBytes: 262_144,
  calls: 8,
  inferenceTimeoutMs: 120_000,
  responseBytes: 1_048_576,
  rounds: 8,
  sessionTimeoutMs: 300_000,
  terminalEventReserveMs: 1_000,
});

export const MAY_TOOL_MAPPINGS = MAY_TOOL_MAPPINGS_V1;

export const MAY_TOOL_DEFINITIONS = Object.freeze([
  Object.freeze({
    type: "function",
    function: Object.freeze({
      name: "writeFile",
      description: "Replace one host-approved UTF-8 repository file at the bound revision and expected digest.",
      parameters: Object.freeze({
        type: "object",
        properties: Object.freeze({
          path: Object.freeze({ type: "string" }),
          content: Object.freeze({ type: "string" }),
          expectedSha256: Object.freeze({ type: "string", description: "Current lowercase SHA-256 or the literal absent." }),
        }),
        required: Object.freeze(["path", "content", "expectedSha256"]),
        additionalProperties: false,
      }),
    }),
  }),
  Object.freeze({
    type: "function",
    function: Object.freeze({
      name: "runValidation",
      description: "Run one exact host-approved validation command by ID without a shell.",
      parameters: Object.freeze({
        type: "object",
        properties: Object.freeze({ commandId: Object.freeze({ type: "string" }) }),
        required: Object.freeze(["commandId"]),
        additionalProperties: false,
      }),
    }),
  }),
]);

const IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._:/@#-]{0,511}$/u;
const REVISION = /^[0-9a-f]{40}$/u;
const SHA256 = /^[0-9a-f]{64}$/u;

function plain(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
}

function exactPlain(value, fields) {
  if (!plain(value)) return false;
  const expected = new Set(fields);
  for (const field of fields) if (!Object.hasOwn(value, field)) return false;
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = typeof key === "string" ? Object.getOwnPropertyDescriptor(value, key) : null;
    if (typeof key !== "string" || !expected.has(key) || !descriptor?.enumerable || !Object.hasOwn(descriptor, "value")) return false;
  }
  return true;
}

function data(value, field) {
  const descriptor = Object.getOwnPropertyDescriptor(value, field);
  return descriptor?.enumerable === true && Object.hasOwn(descriptor, "value") ? descriptor.value : undefined;
}

function denseArray(value) {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) return null;
  const output = [];
  for (const key of Reflect.ownKeys(value)) {
    if (key === "length") continue;
    const descriptor = typeof key === "string" ? Object.getOwnPropertyDescriptor(value, key) : null;
    if (typeof key !== "string" || !/^(?:0|[1-9][0-9]*)$/u.test(key) || !descriptor?.enumerable || !Object.hasOwn(descriptor, "value")) return null;
  }
  for (let index = 0; index < value.length; index += 1) {
    if (!Object.hasOwn(value, index)) return null;
    output.push(Object.getOwnPropertyDescriptor(value, String(index)).value);
  }
  return output;
}

function rootIdentity(info) {
  return `${info.dev}:${info.ino}`;
}

function regularFileIdentity(info) {
  return computeMayRegularFileIdentityV1(info);
}

function executableIdentity(info) {
  return computeMayExecutableIdentityV1(info);
}

function validUtf8String(value) {
  if (typeof value !== "string") return false;
  for (let index = 0; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (code === 0) return false;
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = value.charCodeAt(index + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) return false;
      index += 1;
    } else if (code >= 0xdc00 && code <= 0xdfff) return false;
  }
  return true;
}

function safeArgument(value) {
  return typeof value === "string" && Buffer.byteLength(value, "utf8") <= MAY_EXECUTOR_LIMITS.commandArgumentBytes && !/[\u0000-\u001f\u007f]/u.test(value);
}

function executorError(code, outcome = "failed") {
  const error = new Error(code);
  error.executorOutcome = outcome;
  return error;
}

function boundedError(code) {
  const value = String(code);
  return /^[a-z][a-z0-9_]{0,127}$/u.test(value) ? value : "may_control_loop_failed";
}

function remainingTime(deadline, clock) {
  const remaining = deadline - clock();
  if (!Number.isFinite(remaining) || remaining <= 0) throw new Error("may_control_loop_timeout");
  return remaining;
}

async function withinDeadline(operation, deadline, clock) {
  const timeoutMs = remainingTime(deadline, clock);
  let timer;
  try {
    return await Promise.race([
      Promise.resolve().then(operation),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("may_control_loop_timeout")), timeoutMs); }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

async function readBoundedResponse(response, maxBytes) {
  if (!response?.body || typeof response.body.getReader !== "function") throw new Error("lm_response_body_missing");
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    if (!(value instanceof Uint8Array)) throw new Error("lm_response_chunk_invalid");
    total += value.byteLength;
    if (total > maxBytes) {
      await reader.cancel().catch(() => {});
      throw new Error("lm_response_too_large");
    }
    chunks.push(Buffer.from(value));
  }
  return Buffer.concat(chunks).toString("utf8");
}

async function fetchJson(fetchImpl, url, options, { timeoutMs, maxBytes }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetchImpl(url, { ...options, redirect: "error", signal: controller.signal });
    const raw = await readBoundedResponse(response, maxBytes);
    if (!response.ok) throw new Error("lm_request_failed");
    const parsed = strictParseJson(raw, { maxBytes, maxDepth: 16, rejectControlCharacters: false });
    if (parsed.state !== "valid") throw new Error("lm_response_malformed");
    return parsed.value;
  } catch (error) {
    if (controller.signal.aborted) throw new Error("lm_request_timeout");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function parseAssistantResponse(data) {
  if (!plain(data)) throw new Error("lm_response_malformed");
  const choices = denseArray(Object.getOwnPropertyDescriptor(data, "choices")?.value);
  if (choices === null || choices.length !== 1 || !plain(choices[0])) throw new Error("lm_response_malformed");
  const message = Object.getOwnPropertyDescriptor(choices[0], "message")?.value;
  if (!plain(message) || Object.getOwnPropertyDescriptor(message, "role")?.value !== "assistant") throw new Error("lm_response_malformed");
  const content = Object.getOwnPropertyDescriptor(message, "content")?.value;
  if (content !== null && typeof content !== "string") throw new Error("lm_response_malformed");
  if (typeof content === "string" && Buffer.byteLength(content, "utf8") > MAY_CONTROL_LOOP_LIMITS.responseBytes) throw new Error("lm_response_too_large");
  const rawCalls = Object.hasOwn(message, "tool_calls") ? denseArray(Object.getOwnPropertyDescriptor(message, "tool_calls").value) : [];
  if (rawCalls === null) throw new Error("lm_tool_calls_malformed");
  const toolCalls = rawCalls.map((call) => {
    if (!exactPlain(call, ["id", "type", "function"])) throw new Error("lm_tool_call_malformed");
    const fn = Object.getOwnPropertyDescriptor(call, "function").value;
    const id = Object.getOwnPropertyDescriptor(call, "id").value;
    if (Object.getOwnPropertyDescriptor(call, "type").value !== "function" || !IDENTIFIER.test(String(id)) || !exactPlain(fn, ["name", "arguments"])) throw new Error("lm_tool_call_malformed");
    const name = Object.getOwnPropertyDescriptor(fn, "name").value;
    const args = Object.getOwnPropertyDescriptor(fn, "arguments").value;
    if (typeof name !== "string" || typeof args !== "string" || !Object.hasOwn(MAY_TOOL_MAPPINGS, name)) throw new Error("lm_tool_call_malformed");
    return Object.freeze({ id, type: "function", function: Object.freeze({ name, arguments: args }) });
  });
  if (toolCalls.length > 0 && content !== null && content.trim().length > 0) throw new Error("lm_response_ambiguous");
  return { content, toolCalls, assistantMessage: { role: "assistant", content, ...(toolCalls.length > 0 ? { tool_calls: toolCalls } : {}) } };
}

function normalizeControlRequest(value) {
  if (!exactPlain(value, ["baseUrl", "model", "systemPrompt", "userPrompt", "sessionId", "repositoryRoot", "baseRevision"])) throw new Error("may_control_request_malformed");
  for (const field of ["baseUrl", "model", "systemPrompt", "userPrompt", "sessionId", "repositoryRoot"]) {
    if (typeof data(value, field) !== "string") throw new Error("may_control_request_malformed");
  }
  if (!IDENTIFIER.test(data(value, "sessionId")) || !REVISION.test(data(value, "baseRevision"))) throw new Error("may_control_request_malformed");
  return Object.freeze({
    baseUrl: data(value, "baseUrl"), model: data(value, "model"), systemPrompt: data(value, "systemPrompt"),
    userPrompt: data(value, "userPrompt"), sessionId: data(value, "sessionId"),
    repositoryRoot: data(value, "repositoryRoot"), baseRevision: data(value, "baseRevision"),
  });
}

function normalizeControlDependencies(value) {
  const output = normalizeDependencies(value);
  const fetchImpl = data(value, "fetchImpl");
  if (fetchImpl !== undefined && typeof fetchImpl !== "function") throw new Error("may_executor_configuration_malformed");
  const apiToken = data(value, "apiToken");
  if (apiToken !== undefined && typeof apiToken !== "string") throw new Error("may_executor_configuration_malformed");
  const appendControlEvent = data(value, "appendControlEvent");
  if (typeof appendControlEvent !== "function") throw new Error("may_executor_configuration_malformed");
  return Object.freeze({ ...output, ...(fetchImpl === undefined ? {} : { fetchImpl }), ...(apiToken === undefined ? {} : { apiToken }), appendControlEvent });
}

async function appendControlEvent(dependencies, sessionId, counter, code, identifiers = {}, timing = null) {
  const event = Object.freeze({
    mayControlEventSchemaVersion: 1,
    authority: "non_authoritative",
    eventId: `may-control-event:${sessionId}:${counter}`,
    sessionId,
    code,
    counter,
    toolCallId: identifiers.toolCallId ?? null,
    evidenceRefs: Object.freeze([`may-control:${sessionId}`]),
  });
  const receipt = timing === null
    ? await dependencies.appendControlEvent(event)
    : await withinDeadline(() => dependencies.appendControlEvent(event), timing.deadline, timing.clock);
  if (!exactPlain(receipt, ["eventId", "appended"]) || receipt.eventId !== event.eventId || receipt.appended !== true) throw new Error("may_control_event_receipt_invalid");
}

function releasedToolContent(raw) {
  const body = JSON.stringify({ state: "completed", result: raw });
  return Buffer.byteLength(body, "utf8") <= MAY_CONTROL_LOOP_LIMITS.aggregateOutputBytes ? body : null;
}

function mayEffectKey(request, args, commands) {
  if (request.toolName === "writeFile") {
    return computeMayWriteEffectKeyV1({ path: args.path, content: args.content, expectedSha256: args.expectedSha256 });
  }
  const command = commands.get(args.commandId);
  if (!command) throw new Error("may_validation_command_not_approved");
  return computeMayValidationEffectKeyV1(command);
}

function parseArguments(toolName, raw) {
  if (typeof raw !== "string") throw new Error("may_tool_arguments_malformed");
  const parsed = strictParseJson(raw, { maxBytes: MAY_EXECUTOR_LIMITS.argumentBytes, maxDepth: 3, rejectControlCharacters: false });
  if (parsed.state !== "valid" || !plain(parsed.value)) throw new Error(parsed.code ?? "may_tool_arguments_malformed");
  if (toolName === "writeFile") {
    if (!exactPlain(parsed.value, ["path", "content", "expectedSha256"])) throw new Error("may_tool_arguments_malformed");
    const path = data(parsed.value, "path");
    const content = data(parsed.value, "content");
    const expectedSha256 = data(parsed.value, "expectedSha256");
    if (!validateRepositoryRelativePath(path) || isSensitiveRepositoryPath(path) || !validUtf8String(content) || Buffer.byteLength(content, "utf8") > MAY_EXECUTOR_LIMITS.contentBytes || (expectedSha256 !== "absent" && !SHA256.test(expectedSha256))) {
      throw new Error("may_tool_arguments_malformed");
    }
    return Object.freeze({ path, content, expectedSha256 });
  }
  if (toolName === "runValidation") {
    if (!exactPlain(parsed.value, ["commandId"])) throw new Error("may_tool_arguments_malformed");
    const commandId = data(parsed.value, "commandId");
    if (typeof commandId !== "string" || !IDENTIFIER.test(commandId)) throw new Error("may_tool_arguments_malformed");
    return Object.freeze({ commandId });
  }
  throw new Error("may_tool_unknown");
}

function normalizeRequest(value) {
  if (!exactPlain(value, ["sessionId", "toolCallId", "toolName", "arguments", "repositoryRoot", "baseRevision"])) throw new Error("may_tool_request_malformed");
  for (const field of ["sessionId", "toolCallId"] ) if (typeof data(value, field) !== "string" || !IDENTIFIER.test(data(value, field))) throw new Error("may_tool_request_malformed");
  if (!Object.hasOwn(MAY_TOOL_MAPPINGS, data(value, "toolName")) || typeof data(value, "arguments") !== "string" || typeof data(value, "repositoryRoot") !== "string" || !isAbsolute(data(value, "repositoryRoot")) || !REVISION.test(String(data(value, "baseRevision")))) throw new Error("may_tool_request_malformed");
  return Object.freeze({
    sessionId: data(value, "sessionId"), toolCallId: data(value, "toolCallId"), toolName: data(value, "toolName"),
    arguments: data(value, "arguments"), repositoryRoot: data(value, "repositoryRoot"), baseRevision: data(value, "baseRevision"),
  });
}

function normalizeApprovedFiles(value) {
  const files = denseArray(value);
  if (files === null || files.length === 0) throw new Error("may_executor_configuration_malformed");
  const seen = new Set();
  for (const path of files) {
    if (!validateRepositoryRelativePath(path) || isSensitiveRepositoryPath(path) || seen.has(path)) throw new Error("may_executor_configuration_malformed");
    seen.add(path);
  }
  return Object.freeze([...seen].sort());
}

async function normalizeCommands(value) {
  const commands = denseArray(value);
  if (commands === null || commands.length === 0) throw new Error("may_executor_configuration_malformed");
  const output = new Map();
  for (const command of commands) {
    if (!exactPlain(command, ["commandId", "executable", "args", "timeoutMs"])) throw new Error("may_executor_configuration_malformed");
    const commandId = data(command, "commandId");
    const executable = data(command, "executable");
    const args = denseArray(data(command, "args"));
    const timeoutMs = data(command, "timeoutMs");
    if (typeof commandId !== "string" || !IDENTIFIER.test(commandId) || output.has(commandId) || typeof executable !== "string" || !isAbsolute(executable) || args === null || args.length > MAY_EXECUTOR_LIMITS.commandArguments || args.some((arg) => !safeArgument(arg)) || !Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > MAY_EXECUTOR_LIMITS.commandTimeoutMs) throw new Error("may_executor_configuration_malformed");
    const canonical = await realpath(executable);
    const info = await stat(canonical);
    if (!info.isFile() || (info.mode & 0o111) === 0) throw new Error("may_validation_executable_invalid");
    output.set(commandId, Object.freeze({ commandId, executable: canonical, executableIdentity: executableIdentity(info), args: Object.freeze(args), timeoutMs }));
  }
  return output;
}

function normalizeDependencies(value) {
  if (!plain(value)) throw new Error("may_executor_configuration_malformed");
  const output = {};
  for (const name of ["nextCallSlot", "getAuthorizationContext", "getExecutionContext", "appendIfAbsent", "nextResultRecordId", "now", "readWorkspaceRevision", "readWorkspaceStatus", "nextTemporaryName"]) {
    const item = data(value, name);
    if (typeof item !== "function") throw new Error("may_executor_configuration_malformed");
    output[name] = item;
  }
  for (const name of ["ledgerId", "repositoryId", "reasoningRuntimeId", "toolExecutorId"]) {
    const item = data(value, name);
    if (typeof item !== "string" || !IDENTIFIER.test(item)) throw new Error("may_executor_configuration_malformed");
    output[name] = item;
  }
  output.approvedFiles = normalizeApprovedFiles(data(value, "approvedFiles"));
  output.validationCommands = data(value, "validationCommands");
  const plannedToolOperations = data(value, "plannedToolOperations");
  output.plannedToolOperations = plannedToolOperations === undefined ? undefined : normalizeMayPlannedToolOperationsV1(plannedToolOperations);
  const monotonicNow = data(value, "monotonicNow");
  if (monotonicNow !== undefined && typeof monotonicNow !== "function") throw new Error("may_executor_configuration_malformed");
  output.monotonicNow = monotonicNow ?? (() => Date.now());
  return output;
}

async function createRoot(repositoryRoot) {
  const input = resolve(repositoryRoot);
  const canonical = await realpath(input);
  const info = await stat(canonical);
  if (!info.isDirectory()) throw new Error("may_repository_root_invalid");
  return Object.freeze({ input, canonical, identity: rootIdentity(info) });
}

async function verifyRoot(root) {
  try {
    const [canonical, info] = await Promise.all([realpath(root.input), stat(root.input)]);
    return canonical === root.canonical && info.isDirectory() && rootIdentity(info) === root.identity;
  } catch {
    return false;
  }
}

async function verifyRevision(dependencies, root, baseRevision) {
  if (!(await verifyRoot(root))) throw new Error("may_repository_root_changed");
  const revision = await dependencies.readWorkspaceRevision(root.canonical);
  if (revision !== baseRevision) throw new Error("may_workspace_revision_mismatch");
}

async function verifyWorkspaceState(dependencies, root, baseRevision, ignoredPath = null) {
  await verifyRevision(dependencies, root, baseRevision);
  const changed = denseArray(await dependencies.readWorkspaceStatus(root.canonical));
  if (changed === null) throw new Error("may_workspace_status_malformed");
  const seen = new Set();
  const visible = [];
  for (const path of changed) {
    if (!validateRepositoryRelativePath(path) || isSensitiveRepositoryPath(path) || seen.has(path)) throw new Error("may_workspace_status_malformed");
    seen.add(path);
    if (path === ignoredPath) continue;
    if (!dependencies.approvedFiles.includes(path)) throw new Error("may_workspace_scope_mismatch");
    visible.push(path);
  }
  if ([...seen].some((path, index, values) => index > 0 && values[index - 1].localeCompare(path) >= 0)) throw new Error("may_workspace_status_malformed");
  return Object.freeze(visible);
}

async function matchesTemporaryIdentity(path, identity) {
  const current = await lstat(path).catch(() => null);
  return current?.isFile() && !current.isSymbolicLink() && rootIdentity(current) === identity;
}

async function confinedTarget(root, relativePath) {
  const segments = relativePath.split("/");
  let parent = root.canonical;
  for (const segment of segments.slice(0, -1)) {
    parent = join(parent, segment);
    const info = await lstat(parent).catch(() => null);
    if (!info?.isDirectory() || info.isSymbolicLink()) throw new Error(info?.isSymbolicLink() ? "may_path_symlink_denied" : "may_parent_directory_unavailable");
  }
  const escaped = relative(root.canonical, parent);
  if (escaped === ".." || escaped.startsWith(`..${sep}`) || isAbsolute(escaped)) throw new Error("may_path_escape_denied");
  const path = join(parent, segments.at(-1));
  const info = await lstat(path).catch(() => null);
  if (info?.isSymbolicLink() || (info !== null && !info.isFile())) throw new Error(info?.isSymbolicLink() ? "may_path_symlink_denied" : "may_regular_file_required");
  return { parent, path, info };
}

async function currentDigest(target) {
  if (target.info === null) return null;
  if (target.info.size > MAY_EXECUTOR_LIMITS.currentFileBytes) throw new Error("may_current_file_too_large");
  const handle = await open(target.path, fsConstants.O_RDONLY | (fsConstants.O_NOFOLLOW ?? 0));
  try {
    const opened = await handle.stat();
    if (!opened.isFile() || regularFileIdentity(opened) !== regularFileIdentity(target.info)) throw new Error("may_file_identity_changed");
    const chunks = [];
    let total = 0;
    while (true) {
      const chunk = Buffer.allocUnsafe(16_384);
      const { bytesRead } = await handle.read(chunk, 0, chunk.length, null);
      if (bytesRead === 0) break;
      total += bytesRead;
      if (total > MAY_EXECUTOR_LIMITS.currentFileBytes) throw new Error("may_current_file_too_large");
      chunks.push(chunk.subarray(0, bytesRead));
    }
    const closed = await handle.stat();
    if (regularFileIdentity(opened) !== regularFileIdentity(closed)) throw new Error("may_file_identity_changed");
    return createHash("sha256").update(Buffer.concat(chunks)).digest("hex");
  } finally {
    await handle.close().catch(() => {});
  }
}

async function snapshotWorkspace(root, changedPaths) {
  const snapshot = [];
  for (const path of changedPaths) {
    const target = await confinedTarget(root, path);
    if (target.info === null) {
      snapshot.push(Object.freeze({ path, state: "absent" }));
      continue;
    }
    snapshot.push(Object.freeze({
      path,
      state: "file",
      identity: regularFileIdentity(target.info),
      sha256: await currentDigest(target),
    }));
  }
  return JSON.stringify(snapshot);
}

async function writeApprovedFile(root, request, args, dependencies, plannedOperation) {
  if (!dependencies.approvedFiles.includes(args.path)) throw new Error("may_path_not_approved");
  await verifyWorkspaceState(dependencies, root, request.baseRevision);
  const target = await confinedTarget(root, args.path);
  const digest = await currentDigest(target);
  if ((args.expectedSha256 === "absent" && digest !== null) || (args.expectedSha256 !== "absent" && digest !== args.expectedSha256)) throw new Error("may_file_digest_mismatch");
  if (plannedOperation !== undefined && (
    plannedOperation.toolName !== "writeFile" ||
    plannedOperation.path !== args.path ||
    plannedOperation.content !== args.content ||
    (plannedOperation.precondition.kind === "absent"
      ? target.info !== null || args.expectedSha256 !== "absent"
      : target.info === null || args.expectedSha256 !== plannedOperation.precondition.sha256 || regularFileIdentity(target.info) !== plannedOperation.precondition.regularFileIdentity)
  )) throw new Error("may_planned_write_mismatch");
  await verifyWorkspaceState(dependencies, root, request.baseRevision);
  const temporaryName = dependencies.nextTemporaryName(Object.freeze({ sessionId: request.sessionId, toolCallId: request.toolCallId }));
  if (typeof temporaryName !== "string" || !/^\.shield-may-[A-Za-z0-9_-]{8,64}\.tmp$/u.test(temporaryName)) throw new Error("may_temporary_name_invalid");
  const temporaryPath = join(target.parent, temporaryName);
  let handle;
  let temporaryIdentity = null;
  try {
    handle = await open(temporaryPath, fsConstants.O_WRONLY | fsConstants.O_CREAT | fsConstants.O_EXCL | (fsConstants.O_NOFOLLOW ?? 0), target.info?.mode ?? 0o600);
    const temporaryInfo = await handle.stat();
    if (!temporaryInfo.isFile()) throw new Error("may_temporary_file_invalid");
    temporaryIdentity = rootIdentity(temporaryInfo);
    const bytes = Buffer.from(args.content, "utf8");
    await handle.writeFile(bytes);
    await handle.chmod(target.info === null ? 0o600 : target.info.mode & 0o777);
    await handle.sync();
    await handle.close();
    handle = null;
    const temporaryRelativePath = relative(root.canonical, temporaryPath).split(sep).join("/");
    if (!(await matchesTemporaryIdentity(temporaryPath, temporaryIdentity))) throw new Error("may_temporary_file_changed");
    await verifyWorkspaceState(dependencies, root, request.baseRevision, temporaryRelativePath);
    if (!(await matchesTemporaryIdentity(temporaryPath, temporaryIdentity))) throw new Error("may_temporary_file_changed");
    const rechecked = await confinedTarget(root, args.path);
    const recheckedDigest = await currentDigest(rechecked);
    const recheckedIdentityMatches = target.info === null
      ? rechecked.info === null
      : rechecked.info !== null && regularFileIdentity(rechecked.info) === regularFileIdentity(target.info);
    if (recheckedDigest !== digest || !recheckedIdentityMatches) throw new Error("may_file_identity_changed");
    if (!(await matchesTemporaryIdentity(temporaryPath, temporaryIdentity))) throw new Error("may_temporary_file_changed");
    await rename(temporaryPath, target.path);
    try {
      await verifyWorkspaceState(dependencies, root, request.baseRevision);
    } catch (error) {
      throw executorError(error instanceof Error ? error.message : "may_workspace_scope_mismatch", "uncertain");
    }
    const written = await lstat(target.path);
    if (!written.isFile() || written.isSymbolicLink()) throw executorError("may_file_identity_changed", "uncertain");
    return Object.freeze({ state: "completed", code: "file_written", path: args.path, bytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex") });
  } finally {
    await handle?.close().catch(() => {});
    if (temporaryIdentity !== null) {
      if (await matchesTemporaryIdentity(temporaryPath, temporaryIdentity)) {
        await unlink(temporaryPath).catch(() => {});
      }
    }
  }
}

async function runApprovedValidation(root, request, args, dependencies, commands, plannedOperation) {
  const command = commands.get(args.commandId);
  if (plannedOperation !== undefined && (
    plannedOperation.toolName !== "runValidation" ||
    plannedOperation.commandId !== args.commandId ||
    plannedOperation.executable !== command.executable ||
    plannedOperation.executableIdentity !== command.executableIdentity ||
    plannedOperation.timeoutMs !== command.timeoutMs ||
    JSON.stringify(plannedOperation.args) !== JSON.stringify(command.args)
  )) throw new Error("may_planned_validation_mismatch");
  const workspaceBefore = await verifyWorkspaceState(dependencies, root, request.baseRevision);
  const snapshotBefore = await snapshotWorkspace(root, workspaceBefore);
  const currentExecutable = await stat(command.executable).catch(() => null);
  if (!currentExecutable?.isFile() || executableIdentity(currentExecutable) !== command.executableIdentity) throw new Error("may_validation_executable_changed");
  const startedAt = dependencies.monotonicNow();
  const execution = await new Promise((resolveExecution, rejectExecution) => {
    const child = spawn(command.executable, command.args, {
      cwd: root.canonical,
      env: { LANG: "C", LC_ALL: "C", PATH: dirname(command.executable) },
      detached: process.platform !== "win32",
      shell: false,
      stdio: ["ignore", "pipe", "pipe"],
    });
    const stdout = [];
    const stderr = [];
    let bytes = 0;
    let truncated = false;
    let timedOut = false;
    const terminate = () => {
      try {
        if (process.platform !== "win32" && child.pid !== undefined) process.kill(-child.pid, "SIGKILL");
        else child.kill("SIGKILL");
      } catch {
        child.kill("SIGKILL");
      }
    };
    const collect = (target) => (chunk) => {
      if (truncated) return;
      bytes += chunk.length;
      if (bytes > MAY_EXECUTOR_LIMITS.commandOutputBytes) {
        truncated = true;
        terminate();
      } else target.push(chunk);
    };
    child.stdout.on("data", collect(stdout));
    child.stderr.on("data", collect(stderr));
    child.on("error", () => rejectExecution(new Error("may_validation_launch_failed")));
    const timer = setTimeout(() => { timedOut = true; terminate(); }, command.timeoutMs);
    child.on("close", (code, signal) => {
      clearTimeout(timer);
      if (timedOut) return rejectExecution(executorError("may_validation_timeout", "uncertain"));
      if (truncated) return rejectExecution(executorError("may_validation_output_too_large", "uncertain"));
      resolveExecution({ code, signal, stdout: Buffer.concat(stdout).toString("utf8"), stderr: Buffer.concat(stderr).toString("utf8") });
    });
  });
  try {
    const workspaceAfter = await verifyWorkspaceState(dependencies, root, request.baseRevision);
    const snapshotAfter = await snapshotWorkspace(root, workspaceAfter);
    if (workspaceAfter.length !== workspaceBefore.length || workspaceAfter.some((path, index) => path !== workspaceBefore[index]) || snapshotAfter !== snapshotBefore) {
      throw new Error("may_validation_workspace_changed");
    }
  } catch (error) {
    throw executorError(error instanceof Error ? error.message : "may_workspace_revision_mismatch", "uncertain");
  }
  if (execution.signal !== null) throw new Error("may_validation_signal");
  if (execution.code === null) throw executorError("may_validation_process_state_uncertain", "uncertain");
  if (execution.code !== 0) throw new Error("may_validation_nonzero_exit");
  return Object.freeze({
    state: "completed", code: "validation_completed", commandId: command.commandId,
    exitCode: execution.code, signal: execution.signal, stdout: execution.stdout, stderr: execution.stderr,
    durationMs: Math.max(0, dependencies.monotonicNow() - startedAt),
  });
}

function validateSlot(value, mapping, effectKey) {
  const checked = validateRunnerCyclePlan(value);
  if (checked.state === "invalid") throw new Error("may_authority_slot_malformed");
  const plan = checked.value;
  if (plan.seatId !== "may" || plan.actionId !== mapping.actionId || plan.effectClass !== mapping.effectClass || plan.effectKey !== effectKey) throw new Error("may_authority_slot_mismatch");
  return plan;
}

function validateContextIdentity(context, expected, plan) {
  if (!plain(context)) throw new Error("may_authority_context_malformed");
  const read = (field) => data(context, field);
  if (read("canonicalWritableRoot") !== expected.canonicalRoot || read("repositoryId") !== expected.repositoryId || read("reasoningRuntimeId") !== expected.reasoningRuntimeId || read("toolExecutorId") !== expected.toolExecutorId || read("artifactRevisionId") !== expected.baseRevision) throw new Error("may_authority_context_identity_mismatch");
  const capabilities = denseArray(read("requiredCapabilities"));
  if (capabilities === null || capabilities.length !== 1 || capabilities[0] !== expected.mapping.capability || plan.actionId !== expected.mapping.actionId) throw new Error("may_authority_context_capability_mismatch");
  return context;
}

function runnerResult(plan, outcome, summary, evidenceRefs) {
  return {
    runnerContractVersion: 1, outcome, missionId: plan.missionId, subjectId: plan.subjectId,
    revisionId: plan.revisionId, evaluatedThroughSequence: plan.evaluatedThroughSequence,
    cycleId: plan.cycleId, seatId: plan.seatId, actionId: plan.actionId,
    effectClass: plan.effectClass, effectKey: plan.effectKey, summary, evidenceRefs,
  };
}

export async function runMayToolCall(requestInput, dependenciesInput) {
  const request = normalizeRequest(requestInput);
  const args = parseArguments(request.toolName, request.arguments);
  const mapping = MAY_TOOL_MAPPINGS[request.toolName];
  const dependencies = normalizeDependencies(dependenciesInput);
  const [root, commands] = await Promise.all([createRoot(request.repositoryRoot), normalizeCommands(dependencies.validationCommands)]);
  const effectKey = mayEffectKey(request, args, commands);
  const matchingPlannedOperations = dependencies.plannedToolOperations?.filter(
    (operation) => computeMayPlannedToolEffectKeyV1(operation) === effectKey,
  );
  if (matchingPlannedOperations !== undefined && matchingPlannedOperations.length !== 1) throw new Error("may_planned_operation_mismatch");
  const plannedOperation = matchingPlannedOperations?.[0];
  const expected = Object.freeze({
    canonicalRoot: root.canonical, repositoryId: dependencies.repositoryId,
    reasoningRuntimeId: dependencies.reasoningRuntimeId, toolExecutorId: dependencies.toolExecutorId,
    baseRevision: request.baseRevision, mapping,
  });
  await verifyWorkspaceState(dependencies, root, request.baseRevision);
  const plan = validateSlot(await dependencies.nextCallSlot(Object.freeze({
    sessionId: request.sessionId, toolCallId: request.toolCallId, toolName: request.toolName, effectKey, ...mapping,
  })), mapping, effectKey);
  const authorizer = createPermissionAuthorizer({
    ledgerId: dependencies.ledgerId,
    appendIfAbsent: dependencies.appendIfAbsent,
    getContext: async () => validateContextIdentity(await dependencies.getAuthorizationContext(plan), expected, plan),
  });
  const decision = await authorizer(plan);
  if (decision.outcome !== "allow") throw new Error("may_tool_permission_denied");
  let escrow = null;
  let operationError = null;
  let operationOutcome = "failed";
  const auditedExecutor = createAuditedExecutor({
    ledgerId: dependencies.ledgerId,
    appendIfAbsent: dependencies.appendIfAbsent,
    getContext: async () => validateContextIdentity(await dependencies.getExecutionContext(decision), expected, plan),
    nextRecordId: dependencies.nextResultRecordId,
    now: dependencies.now,
    execute: async () => {
      try {
        const result = request.toolName === "writeFile"
          ? await writeApprovedFile(root, request, args, dependencies, plannedOperation)
          : await runApprovedValidation(root, request, args, dependencies, commands, plannedOperation);
        escrow = result;
        return runnerResult(plan, "completed", request.toolName === "writeFile" ? "Approved revision-bound file write completed." : `Approved validation command completed: ${args.commandId}.`, [`may-executor:${request.sessionId}`]);
      } catch (error) {
        operationError = error instanceof Error && /^[a-z][a-z0-9_]{0,127}$/u.test(error.message) ? error.message : "may_tool_execution_failed";
        operationOutcome = error?.executorOutcome === "uncertain" ? "uncertain" : "failed";
        return runnerResult(plan, operationOutcome, operationOutcome === "uncertain" ? `May executor effect outcome is uncertain (${operationError}); the session must stop.` : `May executor operation failed closed: ${operationError}.`, [`may-executor:${request.sessionId}`]);
      }
    },
  });
  const outcome = await auditedExecutor(plan, decision);
  if (outcome.outcome !== "completed" || escrow === null) {
    escrow = null;
    throw new Error(operationError ?? "may_tool_result_not_releasable");
  }
  return Object.freeze({ ...escrow, attribution: "host_observed_tool_result" });
}

export async function runMayControlLoop(requestInput, dependenciesInput) {
  const request = normalizeControlRequest(requestInput);
  const dependencies = normalizeControlDependencies(dependenciesInput);
  const fetchImpl = dependencies.fetchImpl ?? fetch;
  const clock = dependencies.monotonicNow;
  const sessionDeadline = clock() + MAY_CONTROL_LOOP_LIMITS.sessionTimeoutMs;
  const deadline = sessionDeadline - MAY_CONTROL_LOOP_LIMITS.terminalEventReserveMs;
  const timing = Object.freeze({ deadline, clock });
  const terminalTiming = Object.freeze({ deadline: sessionDeadline, clock });
  let eventCounter = 0;
  let capability;
  try {
    capability = await withinDeadline(() => probeLocalToolModel({
      baseUrl: request.baseUrl, model: request.model, fetchImpl, apiToken: dependencies.apiToken,
      timeoutMs: Math.min(MAY_CONTROL_LOOP_LIMITS.inferenceTimeoutMs, remainingTime(deadline, clock)),
    }), deadline, clock);
    if (capability.loadedInstanceId !== dependencies.reasoningRuntimeId) throw new Error("may_control_runtime_mismatch");
    eventCounter += 1;
    await appendControlEvent(dependencies, request.sessionId, eventCounter, "may_control_started", {}, timing);
  } catch (error) {
    eventCounter += 1;
    const code = boundedError(error instanceof Error ? error.message : "may_control_setup_failed");
    await appendControlEvent(dependencies, request.sessionId, eventCounter, code, {}, terminalTiming);
    throw new Error(code);
  }
  const messages = [
    { role: "system", content: request.systemPrompt },
    { role: "user", content: request.userPrompt },
  ];
  const seenCallIds = new Set();
  let callCount = 0;
  let completedToolCalls = 0;
  let writeCalls = 0;
  let validationCalls = 0;
  let releasedBytes = 0;
  try {
    const plannedCommands = dependencies.plannedToolOperations === undefined
      ? null
      : await normalizeCommands(dependencies.validationCommands);
    for (let round = 0; round < MAY_CONTROL_LOOP_LIMITS.rounds; round += 1) {
      const inferenceTimeout = Math.min(MAY_CONTROL_LOOP_LIMITS.inferenceTimeoutMs, remainingTime(deadline, clock));
      const response = await withinDeadline(() => fetchJson(fetchImpl, `${capability.origin}/v1/chat/completions`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(dependencies.apiToken ? { Authorization: `Bearer ${dependencies.apiToken}` } : {}) },
        body: JSON.stringify({ model: capability.loadedInstanceId, messages, tools: MAY_TOOL_DEFINITIONS, tool_choice: "auto", ...LOCAL_TOOL_SAMPLING }),
      }, { timeoutMs: inferenceTimeout, maxBytes: MAY_CONTROL_LOOP_LIMITS.responseBytes }), deadline, clock);
      const assistant = parseAssistantResponse(response);
      if (assistant.toolCalls.length === 0) {
        const plannedComplete = dependencies.plannedToolOperations === undefined
          ? completedToolCalls > 0 && validationCalls > 0
          : completedToolCalls === dependencies.plannedToolOperations.length
            && writeCalls === dependencies.plannedToolOperations.length - 1
            && validationCalls === 1;
        if (!plannedComplete || typeof assistant.content !== "string" || assistant.content.trim().length === 0) throw new Error("may_control_protocol_incomplete");
        eventCounter += 1;
        await appendControlEvent(dependencies, request.sessionId, eventCounter, "may_control_completed", {}, timing);
        return Object.freeze({
          message: assistant.content,
          attribution: "untrusted_model_output",
          completedToolCalls,
          writeCalls,
          validationCalls,
          releasedBytes,
        });
      }
      messages.push(assistant.assistantMessage);
      if (callCount + assistant.toolCalls.length > MAY_CONTROL_LOOP_LIMITS.calls) throw new Error("may_control_call_cap_reached");
      const batchIds = new Set();
      for (const call of assistant.toolCalls) {
        if (seenCallIds.has(call.id) || batchIds.has(call.id)) throw new Error("may_control_tool_call_id_reused");
        batchIds.add(call.id);
      }
      for (const id of batchIds) seenCallIds.add(id);
      callCount += assistant.toolCalls.length;
      for (const call of assistant.toolCalls) {
        if (dependencies.plannedToolOperations !== undefined) {
          const expectedOperation = dependencies.plannedToolOperations[completedToolCalls];
          if (expectedOperation === undefined || call.function.name !== expectedOperation.toolName) throw new Error("may_control_sequence_mismatch");
          const callArguments = parseArguments(call.function.name, call.function.arguments);
          const callEffectKey = mayEffectKey({ toolName: call.function.name }, callArguments, plannedCommands);
          if (callEffectKey !== computeMayPlannedToolEffectKeyV1(expectedOperation)) throw new Error("may_control_sequence_mismatch");
        }
        const result = await withinDeadline(() => runMayToolCall({
          sessionId: request.sessionId,
          toolCallId: call.id,
          toolName: call.function.name,
          arguments: call.function.arguments,
          repositoryRoot: request.repositoryRoot,
          baseRevision: request.baseRevision,
        }, dependencies), deadline, clock);
        const content = releasedToolContent(result);
        if (content === null || releasedBytes + Buffer.byteLength(content, "utf8") > MAY_CONTROL_LOOP_LIMITS.aggregateOutputBytes) throw new Error("may_control_output_cap_reached");
        releasedBytes += Buffer.byteLength(content, "utf8");
        completedToolCalls += 1;
        if (call.function.name === "writeFile") writeCalls += 1;
        if (call.function.name === "runValidation") validationCalls += 1;
        eventCounter += 1;
        await appendControlEvent(dependencies, request.sessionId, eventCounter, `may_control_${call.function.name}_completed`, { toolCallId: call.id }, timing);
        messages.push({ role: "tool", tool_call_id: call.id, content });
      }
    }
    throw new Error("may_control_round_cap_reached");
  } catch (error) {
    eventCounter += 1;
    const code = boundedError(error instanceof Error ? error.message : "may_control_loop_failed");
    await appendControlEvent(dependencies, request.sessionId, eventCounter, code, {}, terminalTiming);
    throw new Error(code);
  }
}
