# Mission Modes

Use a small core charter plus a mode module loaded at mission start.

## Active order

1. **Debugger Mode** — first module, used for bug investigation and fix flow.
2. **Delivery Mode** — planned engineering work from approved requirements to a
   review-ready pull request.

## Planned next modules

3. **Daily Briefing** — for recurring status checks across Jira, GitHub, and review queues.
4. **Hotfix Response** — for urgent production or release-blocking fixes.

## Mode selection rule

- If the mission starts from a bug, failing test, runtime issue, or unclear defect, load **Debugger Mode**.
- If the mission starts from planned engineering work with a known desired
  outcome, load **Delivery Mode**.
- If the mission is a recurring check or comms sweep, load **Daily Briefing**.
- If the mission is urgent and production-facing, load **Hotfix Response** when it exists.

## Loading rule

Maria Hill selects or confirms the mode at mission start and then follows the matching module.

## Shared iteration rule

Every mode uses the charter's Hill-controlled specialist iteration policy.
Modes may add evidence or validation obligations, but they cannot replace the
policy with a fixed repair count, grant routing authority, or bypass a material
Coulson or final human gate.

## Dynamic composition rule

- seats define identity, authority, and responsibility
- modes define reusable expertise, tools, and mission context
- Maria Hill may attach one or more modes to each participating seat
- only participating seats receive loaded modes for the current mission
- new modes should be addable without rewriting existing seat definitions

## Manual mode select

A human operator may manually choose the active character and one or more modes
for the current mission.

When manual mode selection is provided:

- the selected character and modes determine the generated mission context
- the manual selection overrides automatic mode assignment for that mission
- the default Hill-driven automatic workflow remains the normal path when no
  manual override is provided

## Mid-mission mode requests

If a seat needs expertise or context outside the currently loaded modes, use
`../playbooks/agent-request-mode.md`.

## Composition reference

When a mission needs explicit seat-to-mode mapping, use
`../playbooks/dynamic-mode-composition.md`.
